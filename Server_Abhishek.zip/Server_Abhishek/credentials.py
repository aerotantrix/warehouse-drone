psql_credentials = {
    "host": "192.168.1.100",
    "port": "5432",
    "username": "postgres",
    "password": "",
}

rabbitmq_credentials = {
    "host": "192.168.1.100",
    "port": "5672",
    "username": "postgres",
    "password": "",
    "vhost": "",
}

JWT_SECRET_KEY = "ijoafiodgfsdjm34923rijfdsndshfsndmfnadsfnhaf4tamudgsd"

